# Juber Client

Client for the (J)Uber Clone Course on Nomad Academy. ReactJS, Apollo, Typescript

## Screens:

### Logged Out:

    - [ ] Home
    - [ ] Phone Login
    - [ ] Verifiy Phone Number
    - [ ] Social Login

### Logged In:

    - [ ] Home
    - [ ] Ride
    - [ ] Edit Account
    - [ ] Settings
    - [ ] Places
    - [ ] Add Place
    - [ ] Find Address
    - [ ] Challenge: Ride History
