const theme = {
  blueColor: '#3498db',
  greyColor: '#7f8c8d',
  yellowColor: '#fcc159',
  greenColor: '#77a832',
  redColor: '#ff6842',
};

export default theme;
