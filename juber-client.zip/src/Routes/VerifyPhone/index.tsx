import VerifyPhoneContainer from './VerifyPhoneContainer';
export default VerifyPhoneContainer;
