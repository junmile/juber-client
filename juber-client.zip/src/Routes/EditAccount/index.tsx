import EditAccountContainer from './EditAccountContainer';
export default EditAccountContainer;
