import SocialLoginContainer from './SocialLoginContainer';
export default SocialLoginContainer;
