import SettingContainer from './SettingContainer';
export default SettingContainer;
