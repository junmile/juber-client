import React from 'react';

interface Iprops {
    onChange : any;
}

const EmailLoginPresenter: React.SFC<IProps> = ({onChange}) => ();

export default EmailLoginPresenter;
