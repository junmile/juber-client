import React, { useState } from 'react';
import EmailLoginPresenter from './EmailLoginPresenter';
import { useMutation } from 'react-apollo';

const EmailLoginContainer: React.FC = () => {
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');

  const [EmailSignInFn] = useMutation<
  return (
    <EmailLoginPresenter
      onEmailInputChange={setEmail}
      onPasswordInputChange={setPassword}
    />
  );
};

export default EmailLoginContainer;
