import PlacesContainer from './PlacesContainer';
export default PlacesContainer;
