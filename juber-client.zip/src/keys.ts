export const MAPS_KEY = 'AIzaSyBttpRgtnq8hIllX5c2Imy3sB7lwBiAJKw';
