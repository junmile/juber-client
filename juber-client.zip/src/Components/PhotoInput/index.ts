import PhotoInput from './PhotoInput';
export default PhotoInput;
