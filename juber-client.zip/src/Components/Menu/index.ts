import MenuContainer from './MenuContainer';
export default MenuContainer;
