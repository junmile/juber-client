import PlaceContainer from './PlaceContainer';
export default PlaceContainer;
